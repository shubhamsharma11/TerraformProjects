# This scenario is to check the working of Provisioners

## We have Below components Created
 * Subnet 
 * Network Interface 
 * Public ip 
 * VM created for this.


### To  always run the provisioners, below function to be used inside "null_resource"
```
  triggers = {
    always_run = timestamp()
  }
```

