# Login to Linux machine using SSH Key
## These terraform script are created to deploy a vm and connect with ssh key